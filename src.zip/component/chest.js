function Chest() {
    return (
    <div>
      <h1 align="center">상체 운동</h1>
      <ul>
        <li>
            <h2>가슴 운동</h2>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/0DsXTSHo3lU?si=O0MOg6Mrc775d71E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </li>
        <br></br>
        <li>
            <h2>어깨 운동</h2>
        </li>
      </ul>
      
    </div>
    )
}

export default Chest;