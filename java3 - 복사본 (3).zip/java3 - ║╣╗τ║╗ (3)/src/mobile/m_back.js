import '../../src/css/back.css'

function M_Back(){
    return(
    <div className="m_iframe">
        
        
            <div>
            <h1>턱걸이</h1>
            <iframe className="m_iframe" src="https://www.youtube.com/embed/nWhS28U6bCY?si=QpJjcXifSj5jYKj1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>랫풀다운</h1>
            <iframe className="m_iframe" src="https://www.youtube.com/embed/MpVD4WMoewM?si=cJpHc1E8aoyBDEd2&amp;start=55" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>시티드로우</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/rVWXU4NNzsE?si=v6XVZtFAcDHKjCrU&amp;start=55" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>암풀다운</h1>
            <iframe className="m_iframe" src="https://www.youtube.com/embed/QoAYCFh57_o?si=F-RyPM52sUV_1W96&amp;start=5" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>바벨로우</h1>
            <iframe className="m_iframe" src="https://www.youtube.com/embed/EEqGCoTuYfQ?si=kVAK3GFbpja9zWah&amp;start=29" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            
            

    </div>
    )
}

export default M_Back;
