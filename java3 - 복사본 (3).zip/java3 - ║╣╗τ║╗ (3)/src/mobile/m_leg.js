function M_leg() {
    return (
    <div className="m_iframe">
      <h1 align="center">하체 운동</h1>
      <ul>
        <li>
        <iframe className="m_iframe"  src="https://www.youtube.com/embed/q6hBSSfokzY?si=uh6uCf-q9STvl4MM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </li>
      </ul>
    </div>
    )
}

export default M_leg;