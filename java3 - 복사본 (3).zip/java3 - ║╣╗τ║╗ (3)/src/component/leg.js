import '../../src/css/chest1.css'


function Leg() {
    return (
    <div className='chest1'>
      <div>
        <h1 align="center">스쿼트</h1>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/q6hBSSfokzY?si=uh6uCf-q9STvl4MM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div>
        <h1 align="center">런지</h1>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/NZcwOWUkBt4?si=xd0kZ6iRrp7HaUhF" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div>
        <h1 align="center">레그 프레스</h1>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/EV0F_3S7Sks?si=u0s82sOzyZy_Gw0t" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div>
        <h1 align="center">레그 익스텐션</h1>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/mS9iwXhycJI?si=bFnac0Wxl_T8Ov3T" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div>
        <h1 align="center">레그컬</h1>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/6I0NiRc6yww?si=3IyqVbkFiR6UAKpi" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
    </div>
    )
}

export default Leg;