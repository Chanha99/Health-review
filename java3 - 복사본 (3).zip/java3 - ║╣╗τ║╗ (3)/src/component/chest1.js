import '../../src/css/chest1.css'

function Chest1(){
    return(
    <div className="chest1">
        
        
            <div>
            <h1>벤치 프레스</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/0DsXTSHo3lU?si=O0MOg6Mrc775d71E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>케이블 크로스 오버</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/_FUhaghu_ds?si=yEdiqGIzKc60lKG3" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>체스트 프레스</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/YOF_v_nT1Kg?si=tmg5IC-hWWs79Kr0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>덤벨 벤치프레스</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/DNNcr4_IskA?si=dgwnPv8v0DLTPPYJ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>인클라인 벤치 프레스</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/4HvI_mFhzVQ?si=U2Wx5YSsBhQdnJWs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>딥스</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/pQSfXvaQGas?si=o82SxasJX47wl_Nd" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            
            

    </div>
    )
}

export default Chest1;
