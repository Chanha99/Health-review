import * as React from 'react';
import Box from '@mui/material/Box';
import Rating from '@mui/material/Rating';
import Typography from '@mui/material/Typography';

import { Link } from 'react-router-dom';

function Review_chest() {
  const [pushupRating, setPushupRating] = React.useState(5);
  const [benchpressRating, setbenchpressRating] = React.useState(3);
  const [pullupRating, setPullupRating] = React.useState(4);


  return (
    <>
      <Box sx={{ '& > legend': { mt: 2 } }}>
      <h1><Link to="/review/chest/pushup">푸쉬업</Link></h1>
        <Typography component="legend"></Typography>
        <Rating
          name="pushup-rating"
          value={pushupRating}
          onChange={(event, newValue) => {
            setPushupRating(newValue);
          }}
        />
      </Box>
      <Box sx={{ '& > legend': { mt: 2 } }}>
        <h1>벤치 프레스</h1>
        <Typography component="legend"></Typography>
        <Rating
          name="benchpress-rating"
          value={benchpressRating}
          onChange={(event, newValue) => {
            setbenchpressRating(newValue);
          }}
        />
      </Box>
    </>
  );
}

export default Review_chest;
