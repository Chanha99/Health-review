import React, { useEffect, useState } from 'react';
import '../css/board.css';
import List from './PostList';



const Board = () => {
  
  return (
    <div>
      <List/>
      
    </div>
  );
};

export default Board;