function Review_abs() {
    return(
        <h1>abs</h1>
    )
}

export default Review_abs;