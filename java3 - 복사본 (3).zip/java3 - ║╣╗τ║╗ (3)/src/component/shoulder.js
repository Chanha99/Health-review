import '../../src/css/shoulder.css';

function Shoulder(){
    return(
    <div className="shoulder">
        
            <div>
            <h1>오버헤드 프레스</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/EoGMVSORHtM?si=5B1rIyHktdCRyRk6" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>아놀드 프레스</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/PPy2WOkiGjw?si=Ulv3QtoFmj1LpewV" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>사레레</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/Kz3RCPpeqDw?si=nHhskRB8NxQvb-yi" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>덤벨 프런트 레이즈</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/m0ddyws4VL4?si=SjPNlNnAhxCc5MWQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>덤벨 벤트 오버 레이즈</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/n3aX0oJyvWA?si=ERWd9qT3c-tSzLgj" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            <div>
            <h1>어깨 후면</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/HCnDDAMDKps?si=DU8li5yPH1nbtKGE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
            

    </div>
    )
}

export default Shoulder;
