import { Link } from 'react-router-dom';

function Review() {
    return(
        <div>
            <h1 align="center"><Link to='/review/chest'>가슴 운동</Link></h1><br/>
            <h1 align="center"><Link to='/review/arm'>팔 운동</Link></h1><br/>
            <h1 align="center"><Link to='/review/back'>등 운동</Link></h1><br/>
            <h1 align="center"><Link to='/review/abs'>복근 운동</Link></h1><br/>
            <h1 align="center"><Link to='/review/lowerbody'>하체 운동</Link></h1><br/>
        </div>
    )
}

export default Review;