function Pushup() {
    return(
        <div>
            <h1 >팔굽혀펴기</h1>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/aoH7qNedO8k?si=39j5NI5SO4lfwQKj" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            <h2>사람이 아무런 도구 없이도 할 수 있는 순수 맨몸 운동 중 하나이며, 정자세로 수행 시 자신의 몸무게의 3분의 2, 약 60~70% 정도의 무게를 밀어내는 것과 같다고 한다. 보다 정확한 무게를 알아보는 쉬운 방법은 체중계 위에 양손을 올리고 한번 내려갔다 오는 것이다.

            운동 효과만 보면, 팔굽혀펴기보다 뛰어난 웨이트 트레이닝은 얼마든지 있다. 하지만 대부분의 웨이트 트레이닝들은 특정 근육군에 특화된 운동인 경우가 많은 반면, 팔굽혀펴기는 상체, 가슴 근육과 더불어 전신의 코어 근육들을 균형감 있게 단련시켜 주기 때문에, "전신 근육을 균형있게 발전시킨다"는 현대 웨이트 트레이닝의 취지에 잘 부합하는 운동이다.
            </h2>
        </div>
        
    )
}

export default Pushup;