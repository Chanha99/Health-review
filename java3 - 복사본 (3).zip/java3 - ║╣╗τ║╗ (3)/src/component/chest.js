import { Link } from 'react-router-dom';
import '../css/upbodypng.css';

import myImage1 from '../img/upbody.PNG';
import myImage2 from '../img/side.PNG';
import myImage3 from '../img/back.PNG';


function Chest() {
    return (
    <div>
      
      <h1 align="center">상체 운동</h1>
      <br/>
      <ul className='img_test'>
        <li>
            <Link to="/chest1">
            <h2 align="center">가슴 운동</h2>
            <img src={myImage1}></img>
            </Link>
        </li>
        <br></br>
        <li>
            <Link to="/shoulder">
            <h2 align="center">어깨 운동</h2>
            <img src={myImage2}></img>
            </Link>
        </li>
        <br></br>
        <li>
            <Link to="/back">
            <h2 align="center">등 운동</h2>
            <img src={myImage3}></img>
            </Link>
        </li>
      </ul>
    </div>
    )
}

export default Chest;