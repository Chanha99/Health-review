import { useEffect, useState } from 'react';
import axios from 'axios';

function Review_back() {
  let [like, setLike] = useState();
    // 블로그 이름 목록 초기 셋팅
    let [blogName, setBlogName] = useState([
        "턱 걸이", "푸시업"
      ]);

// 서버에서 좋아요 개수를 가져오는 함수
const fetchLikeCount = async () => {
    try {
      const response = await axios.get('http://43.200.82.84:3001/review/back');
      setLike(response.data.likeCount);
    } catch (error) {
      console.error('Error fetching like count:', error);
    }
  };
  
  // 컴포넌트가 처음 마운트될 때 좋아요 개수를 가져오도록 설정
  useEffect(() => {
    fetchLikeCount();
  }, []);

  const handleLikeClick = async () => {
    try {
      // 서버에 POST 요청 보내기
      const response = await axios.post('http://43.200.82.84:3001/review/back', {});
      console.log(response.data.updatedLikeValue); // 확인용 로그
      // 서버에서 받아온 업데이트된 좋아요 값으로 화면 갱신
      setLike(response.data.updatedLikeValue);
    } catch (error) {
      console.error('Error in handleLikeClick:', error);
    }
  };

  return (
    <div className="list">
      <h3>
        {blogName} 
        <span onClick={handleLikeClick}> 👍 </span>
        {like}
      </h3>
      <hr />
    </div>
  );
}

export default Review_back;