const express = require('express')
const session = require('express-session')
const cors = require('cors');
const mysql = require('mysql');
const path = require('path');
const app = express()
const port = 3001

const db = require('./lib/db');
const sessionOption = require('./lib/sessionOption');
const bodyParser = require("body-parser");
// const bcrypt = require('bcrypt');

app.use(express.static(path.join(__dirname, '/build')));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var MySQLStore = require('express-mysql-session')(session);
var sessionStore = new MySQLStore(sessionOption);
app.use(session({  
	key: 'session_cookie_name',
    secret: '~',
	store: sessionStore,
	resave: false,
	saveUninitialized: false
}))

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {    
    res.sendFile(path.join(__dirname, '/build/index.html'));
})

app.get('/authcheck', (req, res) => {      
    const sendData = { isLogin: "" };
    if (req.session.is_logined) {
        sendData.isLogin = "True"
    } else {
        sendData.isLogin = "False"
    }
    res.send(sendData);
})
 
const connection = mysql.createConnection({
  host: 'login-lecture.c8ilciwaovxp.ap-northeast-2.rds.amazonaws.com',
  user: 'admin',
  password: '11111111',
  database: 'login_lecture',
});

// 게시글 목록 조회 페이지네이션 추가
app.get('/board', (req, res) => {
  const page = req.query.page || 1;
  const pageSize = 10; // 한 페이지에 보여줄 게시글 수
  const offset = (page - 1) * pageSize;

  const countQuery = 'SELECT COUNT(*) as totalCount FROM posts';
  db.query(countQuery, (countErr, countResults) => {
    if (countErr) {
      console.error('Database count query error:', countErr);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    const totalCount = countResults[0].totalCount;

    const query = 'SELECT id, title, author, timestamp, content FROM posts LIMIT ? OFFSET ?';
    db.query(query, [pageSize, offset], (err, results) => {
      if (err) {
        console.error('Database query error:', err);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        // 클라이언트로 전송할 때 ISO 형식으로 변환하지 않음
        const postsWithoutISODate = results.map((post) => ({
          ...post,
          // timestamp: new Date(post.timestamp).toISOString(), // 주석 처리
        }));
        res.setHeader('X-Total-Count', totalCount);
        res.status(200).json(postsWithoutISODate); // ISO 형식으로 변환하지 않은 데이터 전송
      }
    });
  });
});



// 새로운 게시글 작성
app.post('/board', (req, res) => {
  const { title, author, content } = req.body;

  if (!title || !author || !content) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // 클라이언트에서 받은 ISO 형식의 날짜를 JavaScript Date 객체로 파싱
  const clientTimestamp = new Date(req.body.timestamp);

  // 유효한 Date 객체인지 확인
  if (isNaN(clientTimestamp.getTime())) {
    return res.status(400).json({ error: 'Invalid timestamp format' });
  }

  // JavaScript Date 객체를 MySQL DATETIME 형식으로 변환
  const timestamp = clientTimestamp.toISOString().slice(0, 19).replace('T', ' ');

  const query = 'INSERT INTO posts (title, author, timestamp, content) VALUES (?, ?, ?, ?)';
  const values = [title, author, timestamp, content];

  db.query(query, values, (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      // 클라이언트로 전송할 때 ISO 형식으로 변환
      const insertedPost = {
        id: results.insertId,
        title,
        author,
        timestamp: new Date(timestamp).toISOString(),
        content,
      };
      res.status(201).json(insertedPost);
    }
  });
});


// 게시글 상세 조회
app.get('/board/:id', (req, res) => {
  const postId = req.params.id;
  const query = 'SELECT id, title, author, timestamp, content FROM posts WHERE id = ?';
  
  db.query(query, [postId], (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (results.length === 0) {
      res.status(404).json({ error: 'Post not found' });
    } else {
      // 클라이언트로 전송할 때 ISO 형식으로 변환
      const postWithISODate = {
        ...results[0],
        timestamp: new Date(results[0].timestamp).toISOString(),
      };
      res.status(200).json(postWithISODate);
    }
  });
});

// 게시글 댓글 목록 조회
app.get('/board/:id/comments', (req, res) => {
  const postId = req.params.id;
  const query = 'SELECT * FROM comments WHERE post_id = ?';
  db.query(query, [postId], (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(200).json(results);
    }
  });
});

// 새로운 댓글 작성
app.post('/board/:id/comments', (req, res) => {
  const postId = req.params.id;
  const { username, content } = req.body;

  if (!username || !content) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const query = 'INSERT INTO comments (post_id, username, content) VALUES (?, ?, ?)';
  const values = [postId, username, content];

  db.query(query, values, (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json({ id: 
        results.insertId, postId, username, content });
    }
  });
});

//-------------------------------------------------------------------------------

// 상체
// 운동 목록 가져오기
app.get('/review', (req, res) => {
  const query = 'SELECT * FROM exercises';

  db.query(query, (error, results) => {
    if (error) {
      console.error('Database query error:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

// 운동 상세 정보 및 댓글 가져오기
app.get('/review/:id', (req, res) => {
  const exerciseId = req.params.id;
  const exerciseQuery = 'SELECT * FROM exercises WHERE id = ?';
  const commentsQuery = 'SELECT * FROM review_comments WHERE exercise_id = ?';

  db.query(exerciseQuery, [exerciseId], (exerciseError, exerciseResults) => {
    if (exerciseError) {
      console.error('Exercise query error:', exerciseError);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (exerciseResults.length === 0) {
      res.status(404).json({ error: 'Exercise not found' });
    } else {
      db.query(commentsQuery, [exerciseId], (commentsError, commentsResults) => {
        if (commentsError) {
          console.error('Comments query error:', commentsError);
          res.status(500).json({ error: 'Internal Server Error' });
        } else {
          const comments = commentsResults;
          
          // Calculate average rate
          const totalRate = comments.reduce((sum, comment) => sum + comment.rate, 0);
          const averageRate = totalRate / comments.length || 0;

          res.json({ exercise: exerciseResults[0], comments: commentsResults, averageRate });
        }
      });
    }
  });
});


// 새로운 댓글 작성
app.post('/review/:id/comments', (req, res) => {
  const exerciseId = req.params.id;
  const { username, content, rate } = req.body;

  if (!username || !content || !rate) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const query = 'INSERT INTO review_comments (exercise_id, username, content, rate) VALUES (?, ?, ?, ?)';
  const values = [exerciseId, username, content, rate];

  db.query(query, values, (error, results) => {
    if (error) {
      console.error('Database query error:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      const newCommentId = results.insertId;

      // 새로 추가된 댓글을 다시 조회하여 클라이언트에 응답
      const getCommentQuery = 'SELECT * FROM review_comments WHERE id = ?';
      db.query(getCommentQuery, [newCommentId], (getCommentError, getCommentResults) => {
        if (getCommentError) {
          console.error('Get comment query error:', getCommentError);
          res.status(500).json({ error: 'Internal Server Error' });
        } else {
          const newComment = getCommentResults[0];
          res.status(201).json(newComment);
        }
      });
    }
  });
});



  // MySQL 연결 여부 확인
if (!connection._connectCalled) {
  connection.connect((err) => {
    if (err) {
      console.error('Error connecting to MySQL:', err);
      throw err;
    }
  });
}

// MySQL 연결 누수 방지 코드 추가
process.on('SIGINT', function () {
  connection.end();
  process.exit();
});

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})