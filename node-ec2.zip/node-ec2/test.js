const express = require('express')
const app = express()

app.get('/', function (req, res) {
  res.send('메인 화면')
})

app.get('/board', function (req, res) {
    res.send('게시판')
  })

app.get('/board/write', function (req, res) {
   res.send('게시판 글 작성')
})

app.get('/review', function (req, res) {
  res.send('운동 종목')
})

app.get('/review/write', function (req, res) {
  res.send('운동 리뷰 작성')
})

app.get('/info', function (req, res) {
  res.send('내 정보')
})

app.listen(80)